import imaplib
import email
from openpyxl import Workbook

m = imaplib.IMAP4_SSL("imap.gmail.com", 993)
m.login("sabanawaz099@gmail.com", "Pakistan@!@#123")
m.select('"[Gmail]/All Mail"')

result, data = m.uid('search', None, "ALL")
to_email = []
from_email = []
subject = []
if result == 'OK':
    for num in data[0].split():
        result, data = m.uid('fetch', num, '(RFC822)')
        if result == 'OK':
            email_message = email.message_from_bytes(data[0][1])    # raw email text including headers
            to_email.append('To:' + email_message['To'])
            from_email.append('From:' + email_message['From'])
            subject.append('Subject:' + str(email_message['Subject']))
            # save the result in the Excel sheet
            final = zip(to_email, from_email, subject)

            # creating Excel sheet
            wb = Workbook()
            sh1 = wb.active

            for c1 in list(final):
                sh1.append(c1)

            wb.save("Email_details.xlsx")


